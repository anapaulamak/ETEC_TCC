﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de DadosEImagem
/// </summary>
public class DadosEImagem
{
    public string Nome { get; set; }
    public byte[] Caminho { get; set; }


    public DadosEImagem()
    {
        //
        // TODO: Adicionar lógica do construtor aqui
        //
    }
}
